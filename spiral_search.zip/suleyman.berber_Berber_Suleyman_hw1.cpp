#include <iostream>
#include "strutils.h"
#include <fstream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

// The file_check function is meant to validate the content of an input file, checking if the file mind with certain rules related to matrix data and search terms. If all the checks pass, it returns true, indicating that the file is valid, and if any of the checks fail, it returns false.
bool file_check (ifstream &file_input, string &search_number, string &matrix_number) {
    
    bool control = true;
    file_input >> matrix_number;
   
    
    for (int i = 0; i< atoi(matrix_number); i++)
    {
        string word;
        file_input >> word;
        if (word.length() != atoi(matrix_number))
            control = false;

        for (int i= 0; i< word.length(); i++)
        {
            if (!(word[i]<= 90 && word[i]>=65))
                control = false;
        }
    }
    file_input >> search_number;
    for (int j = 0; j< atoi(search_number); j++)
    {
        string s_word;
        file_input >> s_word;
        
        for (int k= 0; k< s_word.length(); k++)
        {
            if (!(s_word[k]<= 90 && s_word[k]>=65))
            {
                control = false;
            }
        }
    }
    file_input.seekg(0);
    return control;
}

// The transfer_matrix function reads data from the input file and builds a 2D matrix of strings and vectors of search words. This function takes care of parsing the dimensions, matrix data, and search terms from the file and settle the corresponding data structures.
void transfer_matrix (ifstream &file_input, vector <vector<string>> &mat, vector <string> &s_words){
    
    string num1, num2;
    file_input >> num1;
    for (int i = 0; i< atoi(num1); i++)
    {
        string word;
        file_input >> word;
        for (int j=0; j<atoi(num1); j++)
        {
            mat[i][j] = word[j];
        }
    }
    file_input >> num2;
    for (int j = 0; j< atoi(num2); j++)
    {
        string s_word;
        file_input >> s_word;
        s_words.push_back(s_word);
    }
}

// The right function is designed to move right through the matrix and add the string values ​​encountered along the way to the temporary string. The function updates the row and column positions to reflect the new position after moving right.
void right (int &row, int &column, string &temp, const vector <vector<string>> &mat){
    
    column += 1;
    temp += mat[row][column];
}

// The left function is designed to move  left in a matrix and add string values ​​encountered during the process to the temporary string. The function updates the row and column positions to reflect the new position after moving left.
void left (int &row, int &column, string &temp, const vector <vector<string>> &mat){
 
    column -= 1;
    temp += mat[row][column];
}

// The up function is designed to move up in an array and add string values ​​encountered during the process to the temporary string. The function updates the row and column positions to reflect the new position after proceeding.
void up (int &row, int &column, string &temp, const vector <vector<string>> &mat){
    
    row -= 1;
    temp += mat[row][column];
}

// The down function is designed to move down in a matrix and add string values ​​encountered during the process to the temporary string. The function updates the row and column positions to reflect the new position after moving down.
void down (int &row, int &column, string &temp, const vector <vector<string>> &mat){
    
    row += 1;
    temp += mat[row][column];
}

// The go_left function is used to move left in the  matrix and collect string values ​​from the matrix while complying with specific conditions. The number of times this left movement is repeated is controlled by the repetition setting. The function continues moving  left and adding characters at temp until the leftmost boundary is reached or the temporary string reaches the specified length.
void go_left (int repeat, int &row, int &column, string &temp, const vector <vector<string>> &mat, int len)
{
    for (int i=0; i<repeat; i++)
    {
        if (column!= 0 && temp.length()<len)
        {
            left(row, column, temp, mat);
            if (temp.length() == len)
                break;
        }
    }
}

// The go_right function is used to move right in the  matrix and collect string values ​​from the matrix while complying with specific conditions. The number of times this right movement is repeated is controlled by the repetition setting. The function continues moving right and adding characters at temp until the rightmost boundary is reached or the temporary string reaches the specified length.
void go_right (int repeat, int &row, int &column, string &temp, const vector <vector<string>> &mat, int len)
{
    for (int i=0; i<repeat; i++)
    {
        if (column!= mat.size()-1 && temp.length()<len)
        {
            right(row, column, temp, mat);
            if (temp.length() == len)
                break;
        }
    }
}

// The go_up function is used to move up in the matrix and collect series values ​​from the matrix while complying with specific conditions. The number of repetitions of this upward movement is  controlled by the repetition setting. The function continues to increment and add characters at the temp until the upper limit is reached or the temp string reaches the specified length.
void go_up (int repeat, int &row, int &column, string &temp, const vector <vector<string>> &mat, int len)
{
    for (int i=0; i<repeat; i++)
    {
        if (row!= 0 && temp.length()<len)
        {
            up(row, column, temp, mat);
            if (temp.length() == len)
                break;
        }
    }
}

// The go_down function is used to move down in the matrix and collect series values ​​from the matrix while complying with specific conditions. The number of repetitions of this downward movement is  controlled by the repetition setting. The function continues to increment and add characters at the temp until the downer limit is reached or the temp string reaches the specified length.
void go_down (int repeat, int &row, int &column, string &temp, const vector <vector<string>> &mat, int len)
{
    for (int i=0; i<repeat; i++)
    {
        if (row!= mat.size()-1 && temp.length()<len)
        {
            down(row, column, temp, mat);
            if (temp.length() == len)
                break;
        }
    }
}
   
//  The found_right function is a part of a search algorithm that navigates a matrix in a specific sequence of movements to find a target word. It alternates between right, down, left and up movements and constructs the target word in the temp string. If the word is found, it sets the flag to true, indicating a successful search.
bool found_right (vector <vector<string>> &mat, int row, int column, string s_word, string first_move, string &temp)
{
    bool flag = false;
    if (first_move == "right")
    {
        int temp_row, temp_column;
        if (column!= mat.size()-1 && mat[row][column+1]==s_word.substr(1,1))
        {
            right(row,column, temp, mat);
            temp_row = row;
            temp_column = column;
            
            if (row != mat.size()-1 && mat[row+1][column]==s_word.substr(2,1))
            {
                down(row, column, temp, mat);
                for (int i=2; i<s_word.length(); i +=1)
                {
                    go_left (i, row, column, temp, mat, s_word.length());
                    go_up (i, row, column, temp, mat, s_word.length());
                    i++;
                    go_right (i, row, column, temp, mat, s_word.length());
                    go_down (i, row, column, temp, mat, s_word.length());
                    if (temp.length()==s_word.length())
                        break;
                }
                if (temp == s_word)
                    flag = true;
            }
            if (flag == false)
            {
                row = temp_row;
                column = temp_column;
                if (row != 0 && mat[row-1][column]==s_word.substr(2,1))
                {
                    temp = s_word.substr(0,2);
                    up(row,column, temp, mat);
                    for (int i=2; i<s_word.length(); i +=1)
                    {
                        go_left (i, row, column, temp, mat, s_word.length());
                        go_down (i, row, column, temp, mat, s_word.length());
                        i++;
                        go_right (i, row, column, temp, mat, s_word.length());
                        go_up (i, row, column, temp, mat, s_word.length());
                        if (temp.length()==s_word.length())
                            break;
                    }
                    if (temp == s_word)
                        flag = true;
                }
            }
        }
    }
    return flag;
}

// The found_left function is part of a search algorithm that navigates a matrix using a specific sequence of movements to search for a target word. It alternates between left, right, up and down movements and constructs the target word in the temp string. If the word is found, it sets the flag to `true, indicating a successful search.
bool found_left (vector <vector<string>> &mat, int row, int column, string s_word, string first_move, string &temp)
{
    bool flag = false;
    
    if (first_move == "left")
    {
        int temp_row, temp_column;
        if (column!= 0 && mat[row][column-1]==s_word.substr(1,1))
        {
            left(row, column, temp, mat);
            temp_row = row;
            temp_column = column;
            
            if (row != 0 && mat[row-1][column]==s_word.substr(2,1))
            {
                up(row, column, temp, mat);
                for (int i=2; i<s_word.length(); i +=1)
                {
                    go_right (i, row, column, temp, mat, s_word.length());
                    go_down (i, row, column, temp, mat, s_word.length());
                    i++;
                    go_left (i, row, column, temp, mat, s_word.length());
                    go_up (i, row, column, temp, mat, s_word.length());
                    if (temp.length()==s_word.length())
                        break;
                }
                if (temp == s_word)
                    flag = true;
            }
            if (flag == false)
            {
                row = temp_row;
                column = temp_column;
                if (row != mat.size()-1 && mat[row+1][column]==s_word.substr(2,1))
                {
                    temp = s_word.substr(0,2);
                    down(row, column, temp, mat);
                    for (int i=2; i<s_word.length(); i +=1)
                    {
                        go_right (i, row, column, temp, mat, s_word.length());
                        go_up (i, row, column, temp , mat, s_word.length());
                        i++;
                        go_left (i, row, column, temp, mat, s_word.length());
                        go_down (i, row, column, temp, mat, s_word.length());
                        if (temp.length()==s_word.length())
                            break;
                    }
                    if (temp == s_word)
                        flag = true;
                }
            }
        }
    }
    return flag;
}

// The found_up function is part of a search algorithm that navigates a matrix using a specific sequence of movements to search for a target word. It alternates between up, left, down and right movements and constructs the target word in the temp string. If the word is found, it sets the flag to `true, indicating a successful search.
bool found_up (vector <vector<string>> &mat, int row, int column, string s_word, string first_move, string &temp)
{
    bool flag = false;
    
    if (first_move == "up")
    {
        int temp_row, temp_column;
        if (row !=0 && mat[row-1][column]==s_word.substr(1,1))
        {
            up(row, column, temp, mat);
            temp_row = row;
            temp_column = column;
            if (column != mat.size()-1 && mat[row][column+1]==s_word.substr(2,1))
            {
                right(row, column, temp, mat);
                for (int i=2; i<s_word.length(); i +=1)
                {
                    go_down (i, row, column, temp, mat, s_word.length());
                    go_left (i, row, column, temp, mat, s_word.length());
                    i++;
                    go_up (i, row, column, temp, mat, s_word.length());
                    go_right (i, row, column, temp, mat, s_word.length());
                    if (temp.length()==s_word.length())
                        break;
                }
                if (temp == s_word)
                    flag = true;
            }
            if (flag == false)
            {
                row = temp_row;
                column = temp_column;
                if (column !=0 && mat[row][column-1]==s_word.substr(2,1))
                {
                    temp = s_word.substr(0,2);
                    left(row,column, temp, mat);
                    for (int i=2; i<s_word.length(); i +=1)
                    {
                        go_down (i, row, column, temp, mat, s_word.length());
                        go_right (i, row, column, temp, mat, s_word.length());
                        i++;
                        go_up (i, row, column, temp, mat, s_word.length());
                        go_left (i, row, column, temp, mat, s_word.length());
                        if (temp.length()==s_word.length())
                            break;
                    }
                    if (temp == s_word)
                        flag = true;
                }
            }
        }
    }
    return flag;
}

// The found_down function is part of a search algorithm that navigates a matrix using a specific sequence of movements to search for a target word. It alternates between down, right, left and up movements to construct the target word in the temp string. If the word is found, it sets the flag to true, indicating a successful search.
bool found_down (vector <vector<string>> &mat, int row, int column, string s_word, string first_move, string &temp)
{
    bool flag = false;
    if (first_move == "down")
    {
        int temp_row, temp_column;
        if (row != mat.size()-1 && mat[row+1][column]==s_word.substr(1,1))
        {
            down(row, column, temp, mat);
            temp_row = row;
            temp_column = column;
            if (column != 0 && mat[row][column-1]==s_word.substr(2,1))
            {
                left(row,column, temp, mat);
                for (int i=2; i<s_word.length(); i +=1)
                {
                    go_up (i, row, column, temp, mat, s_word.length());
                    go_right (i, row, column, temp, mat, s_word.length());
                    i++;
                    go_down (i, row, column, temp, mat, s_word.length());
                    go_left (i, row, column, temp, mat, s_word.length());
                    if (temp.length()==s_word.length())
                        break;
                }
                if (temp == s_word)
                    flag = true;
            }
            if (flag == false)
            {
                row = temp_row;
                column = temp_column;
                if (column != mat.size()-1 && mat[row][column+1]==s_word.substr(2,1))
                {
                    temp = s_word.substr(0,2);
                    right(row,column, temp, mat);
                    for (int i=2; i<s_word.length(); i +=1)
                    {
                        go_up (i, row, column, temp, mat, s_word.length());
                        go_left (i, row, column, temp, mat, s_word.length());
                        i++;
                        go_down (i, row, column, temp, mat, s_word.length());
                        go_right (i, row, column, temp, mat, s_word.length());
                        if (temp.length()==s_word.length())
                            break;
                    }
                    if (temp == s_word)
                        flag = true;
                }
            }
        }
    }
    return flag;
}

// The print_words function is used to display the words that have been found during a search process. It prints the count of found words and lists them in the order they appear in the p_words vector.
void print_words (const vector <string> p_words)
{
    cout << p_words.size() << " Words are Found:  ";
    for (int m=0; m<p_words.size();m++)
    {
        cout << p_words[m] << " ";
    }
}

// The control_word function is used to prevent the duplication of words in the word vector. It checks if a given word (temp) is already present in the vector and returns true if it's not, indicating that the word is unique. If the word is found in the vector, it returns false.
bool control_word (vector <string> word, string temp)
{
    bool flag = true;
    for (int i =0; i<word.size(); i++)
    {
        if (temp == word[i])
            flag = false;
    }
    return flag;
}
// The search function is a word search algorithm that systematically searches for multiple target words within a matrix by using found_down, found_up, found_left and found_right functions, considering various directions, and collects and prints the words that are found by using print_words function. It's a comprehensive search algorithm that combines several other functions to achieve its goal.
void search (vector <vector<string>> &mat, const vector <string> s_words){
    
    vector <string> word;
    for (int i = 0; i<s_words.size(); i++)
    {
        for (int j = 0; j<mat.size(); j++)
        {
            for (int k = 0; k<mat[0].size(); k++)
            {
                string s_word = s_words[i];
                if (mat[j][k] == s_word.substr(0,1))
                {
                    int len = s_word.length();
                    string temp = "";
                    temp +=s_word.substr(0,1);
                    if (found_right (mat, j, k, s_word, "right", temp) == true)
                    {
                        if (control_word (word,  temp)== true)
                            word.push_back(temp);
                        i++;
                        j = 0;
                        k= 0;
                        
                        if (i == s_words.size())
                        {
                            j = mat.size();
                            k = mat.size();
                            break;
                        }
                    }
                    temp = "";
                    s_word = s_words[i];
                    temp +=s_word.substr(0,1);
                    if (found_left (mat, j, k, s_word, "left", temp) == true)
                    {
                        if (control_word (word,  temp)== true)
                            word.push_back(temp);
                        i++;
                        j = 0;
                        k= 0;
                        
                        if (i == s_words.size())
                        {
                            j = mat.size();
                            k = mat.size();
                            break;
                        }
                    }
                    temp = "";
                    s_word = s_words[i];
                    temp +=s_word.substr(0,1);
                    if (found_up (mat, j, k, s_word, "up", temp) == true)
                    {
                        if (control_word (word,  temp)== true)
                            word.push_back(temp);
                        i++;
                        j = 0;
                        k= 0;
                        
                        if (i == s_words.size())
                        {
                            j = mat.size();
                            k = mat.size();
                            break;
                        }
                    }
                    temp = "";
                    s_word = s_words[i];
                    temp +=s_word.substr(0,1);
                    if (found_down (mat, j, k, s_word, "down", temp) == true)
                    {
                        if (control_word (word,  temp)== true)
                            word.push_back(temp);
                        i++;
                        j = 0;
                        k= 0;
                        
                        if (i == s_words.size())
                        {
                            j = mat.size();
                            k = mat.size();
                            break;
                        }
                    }
                }
            }
        }
    }
    print_words (word);
}

int main() {
        
    ifstream input;
    bool flag;
    do {
        flag = true;
        string file_name;
        cout << "Enter the name of the file ";
        cin >> file_name;
        input.open(file_name.c_str());
        
        if (input.fail())
        {
            cout << "Could not open the file " << file_name << endl;
            flag = false;
        }
        
    } while (flag == false);
    
    string search_num, matrix_num;
    vector <string> search_words;
    
    if (file_check( input, search_num, matrix_num)==false)
    {
        cout << "Error: Input file is not in correct format!" << endl;
    }
    else
    {
        vector<vector<string>> matrix(atoi(matrix_num),vector<string>(atoi(matrix_num)));
        transfer_matrix (input, matrix, search_words);
        search (matrix, search_words);
    }
    return 0;
}
// SULEYMAN BERBER
